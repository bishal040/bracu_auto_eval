// ============================================
// BRACU Auto Evaluator - Popup Script
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // --- State ---
  let selectedRating = 5;
  let selectedSpeed = 'normal';

  // --- DOM Elements ---
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const btnEvaluateAll = document.getElementById('btnEvaluateAll');
  const btnEvaluateCurrent = document.getElementById('btnEvaluateCurrent');
  const progressSection = document.getElementById('progressSection');
  const progressBar = document.getElementById('progressBar');
  const progressLabel = document.getElementById('progressLabel');
  const progressCount = document.getElementById('progressCount');
  const progressDetail = document.getElementById('progressDetail');

  // --- Rating Buttons ---
  document.querySelectorAll('.rating-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.rating-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedRating = parseInt(btn.dataset.value);
    });
  });

  // --- Speed Buttons ---
  document.querySelectorAll('.speed-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.speed-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedSpeed = btn.dataset.speed;
    });
  });

  // --- Check if we're on the right page ---
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (tab && tab.url && tab.url.includes('courseevaluation.bracu.ac.bd')) {
      statusDot.classList.add('connected');
      statusText.textContent = 'Connected to BRACU Evaluation';
      btnEvaluateAll.disabled = false;
      btnEvaluateCurrent.disabled = false;
    } else {
      statusDot.classList.add('error');
      statusText.textContent = 'Please open courseevaluation.bracu.ac.bd';
      btnEvaluateAll.disabled = true;
      btnEvaluateCurrent.disabled = true;
    }
  });

  // --- Evaluate All Courses ---
  btnEvaluateAll.addEventListener('click', () => {
    const speedMs = selectedSpeed === 'fast' ? 300 : selectedSpeed === 'normal' ? 600 : 1200;
    
    progressSection.style.display = 'block';
    progressLabel.textContent = 'Starting evaluation...';
    progressBar.style.width = '0%';
    btnEvaluateAll.disabled = true;
    btnEvaluateCurrent.disabled = true;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'evaluateAll',
        rating: selectedRating,
        speed: speedMs
      });
    });
  });

  // --- Evaluate Current (open modal) Course ---
  btnEvaluateCurrent.addEventListener('click', () => {
    const speedMs = selectedSpeed === 'fast' ? 300 : selectedSpeed === 'normal' ? 600 : 1200;

    progressSection.style.display = 'block';
    progressLabel.textContent = 'Evaluating current...';
    progressBar.style.width = '0%';
    btnEvaluateAll.disabled = true;
    btnEvaluateCurrent.disabled = true;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'evaluateCurrent',
        rating: selectedRating,
        speed: speedMs
      });
    });
  });

  // --- Listen for progress updates from content script ---
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'progress') {
      progressSection.style.display = 'block';
      progressLabel.textContent = message.label || 'Evaluating...';
      progressCount.textContent = message.count || '';
      progressBar.style.width = (message.percent || 0) + '%';
      progressDetail.textContent = message.detail || '';
    }

    if (message.type === 'complete') {
      progressLabel.textContent = '✅ All done!';
      progressBar.style.width = '100%';
      progressDetail.textContent = message.detail || 'All evaluations completed successfully!';
      progressCount.textContent = '';
      btnEvaluateAll.disabled = false;
      btnEvaluateCurrent.disabled = false;
    }

    if (message.type === 'error') {
      progressLabel.textContent = '❌ Error';
      progressDetail.textContent = message.detail || 'Something went wrong.';
      progressBar.style.width = '0%';
      btnEvaluateAll.disabled = false;
      btnEvaluateCurrent.disabled = false;
      statusDot.classList.remove('connected');
      statusDot.classList.add('error');
    }
  });
});
